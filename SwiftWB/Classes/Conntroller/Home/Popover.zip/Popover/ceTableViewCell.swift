//
//  ceTableViewCell.swift
//  
//
//  Created by 殷年平 on 2017/7/22.
//
//

import UIKit

class ceTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
