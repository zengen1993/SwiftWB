//
//  HomeCollectionViewCell.swift
//  SwiftWB
//
//  Created by 殷年平 on 2017/7/24.
//  Copyright © 2017年 Apple. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
